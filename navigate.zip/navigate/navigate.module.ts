import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { NavigateComponent } from './navigate.component';

@NgModule({
  declarations: [NavigateComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [NavigateComponent]
})
export class NavigateModule { }
