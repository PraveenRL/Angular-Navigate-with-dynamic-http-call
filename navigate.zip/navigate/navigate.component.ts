import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { EmptyService } from '../empty/empty.service';

@Component({
  selector: 'app-navigate',
  templateUrl: './navigate.component.html',
  styleUrls: ['./navigate.component.css']
})
export class NavigateComponent implements OnInit {

  @Output() showListEvent = new EventEmitter();
  public currentData = [];
  public currentIndex = 0;

  constructor(
    private emptyService: EmptyService
  ) { }

  ngOnInit() {
    this.fetchData(0, 100);
  }

  private async fetchData(from: number, to: number) {
    return this.emptyService.getMockData(from, to).toPromise().then(response => {
      this.currentData = response;
      console.log(this.currentData);
      if (from === 0) {
        this.showListEvent.emit(this.currentData[0]);
      }
    });
  }

  public async onClickNavigate(direction: string) {
    switch (direction) {
      case 'left':
        if ((this.currentIndex) % 100 === 0 && this.currentIndex > 1) {
          await this.fetchData(this.currentIndex - 100, this.currentIndex);
          console.log(`From ${this.currentIndex - 100} To ${this.currentIndex}`);
        }

        this.currentIndex--;
        break;

      case 'right':
        this.currentIndex++;

        if ((this.currentIndex) % 100 === 0 && this.currentIndex > 1) {
          await this.fetchData(this.currentIndex, this.currentIndex + 100);
          console.log(`From ${this.currentIndex} To ${this.currentIndex + 100}`);
        }
        break;

      default:
        break;
    }

    let showIndex = null;
    if (this.currentIndex >= 100) {
      showIndex = this.currentIndex - Math.floor(this.currentIndex / 100) * 100;
    } else {
      showIndex = this.currentIndex;
    }
    console.log(this.currentIndex, showIndex);
    this.showListEvent.emit(this.currentData[showIndex]);
  }

}
